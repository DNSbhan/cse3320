/*dinesh bhandari
1001802374
class 3320-001
assignment-2
date-06-24-2021
*/

here is a sample output for my assigment 2. it only works for part 1.


pi@raspberrypi:~/Desktop/myas2 $ gcc -o u utility.c 
pi@raspberrypi:~/Desktop/myas2 $ gcc driver1.c
pi@raspberrypi:~/Desktop/myas2 $ ./a.out
Enter 1 for normal process call 
 2 for 2 process call 
 4 for 4 process call 
 10 for 10 process calln4
PID : 7276 PPID : 7274 Driver time Start: Thu Jun 24 17:43:24 2021
PID : 7275 PPID : 7274 Driver time Start: Thu Jun 24 17:43:24 2021
PID : 7274 PPID : 1693 Driver time Start: Thu Jun 24 17:43:24 2021
PID : 7277 PPID : 7275 Driver time Start: Thu Jun 24 17:43:24 2021
 Number of entries found: 12888
 Number of entries found: 12888
 Number of entries found: 12888
 Number of entries found: 12888
PID : 7275 PPID : 7274 Driver time End: Thu Jun 24 17:43:25 2021

PID : 7276 PPID : 7274 Driver time End: Thu Jun 24 17:43:25 2021

PID : 7274 PPID : 1693 Driver time End: Thu Jun 24 17:43:25 2021

pi@raspberrypi:~/Desktop/myas2 $ PID : 7277 PPID : 1 Driver time End: Thu Jun 24 17:43:25 2021
