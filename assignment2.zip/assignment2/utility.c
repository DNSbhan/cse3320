#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

struct lnode {
 char *str;
 double latitude;
 float longitude;
 float depth;
 float mag;
 char *magType;
 char *nst;
 int gap;
 float dmin;
 float rms;
 char *net;
 char *id;
 char *updated;
 char *place;
 char *type;
 float horizontalError;
 float depthError;
 float magError;
 int magNst;
 char *status;
 char *locationSource;
 char *magSource;
 struct lnode *next;
};

struct lnode *insert(char *data, double latitude, float longitude, float depth, float mag, char *magType, char *nst, int gap, float dmin, float rms, char *net, char *id, char *updated, char *place, char *type, float horizontalError, float depthError, float magError, int magNst, char *status, char *locationSource, char *magSource, struct lnode *list);
void free_list(struct lnode *list);
void print_list(struct lnode *list);

int main() {
 clock_t start, end;
 time_t t;
 struct lnode *list;
 char line[1024];
 double latitude, cpu_time;
 float longitude, depth, mag, dmin, rms, horizontalError, depthError, magError;
 int gap, magNst;
 char magType[5], nst[5], net[5], id[25], updated[100], place[200], type[15], status[15], locationSource[5], magSource[5];
 start = clock();
 list = NULL;
 t = time(NULL);
 printf("PID : %d PPID : %d Driver time Start: %s ", getpid(), getppid(), ctime(&t));
 char* csv_filename = "all_month.csv";
 FILE* fp = fopen(csv_filename,"r");
   //check if file opened properly or not
   if (!fp)
        printf("Can't open file\n");
   else {
        // Here we have taken size of
        // array 1024 you can modify it
        char buffer[1024];
        int row = 0;
        int column = 0;

        while (fgets(buffer,
                     1024, fp)) {
            column = 0;
            row++;

            // To avoid printing of column
            // names in file can be changed
            // according to need
            if (row == 1)
                continue;
            // Splitting the data
            char* value = strtok(buffer, ", ");
  	    char* ptr;
            while (value) {
                // Column 1
                if (column == 0) {
                    strcpy(line, value);
                }

                // Column 2
                if (column == 1) {
                    latitude = strtod(value, &ptr);
                }
		// Column 3
                if (column == 2) {
                    longitude = atof(value);
                }

                // Column 4
                if (column == 3) {
                    depth = atof(value);
                }// Column 5
                if (column == 4) {
                    mag = atof(value);
                }

                // Column 6
                if (column == 5) {
                    strcpy(magType,value);
                }// Column 7
                if (column == 6) {
                    strcpy(nst,value);
                }

                // Column 8
                if (column == 7) {
                    gap = atoi(value);
                }// Column 9
                if (column == 8) {
                    dmin = atof(value);
                }

                // Column 10
                if (column == 9) {
                    rms = atof(value);
                }// Column 11
                if (column == 10) {
                    strcpy(net,value);
                }

                // Column 12
                if (column == 11) {
                    strcpy(id,value);
                }// Column 13
                if (column == 12) {
                    strcpy(updated,value);
                }

                // Column 14
                if (column == 13) {
                    strcpy(place,value);
                }// Column 15
                if (column == 14) {
                    strcpy(type,value);
                }

                // Column 16
                if (column == 15) {
                    horizontalError = atof(value);
                }// Column 17
                if (column == 16) {
                    depthError=atof(value);
                }

                // Column 18
                if (column == 17) {
                    magError=atof(value);
                }// Column 19
                if (column == 18) {
                    magNst=atoi(value);
                }

                // Column 20
                if (column == 19) {
                    strcpy(status,value);
                }// Column 21
                if (column == 20) {
                    strcpy(locationSource,value);
                }

                // Column 22
                if (column == 21) {
                    strcpy(magSource,value);
                }

                value = strtok(NULL, ", ");
                column++;
            }
  	    list = insert(line, latitude, longitude, depth, mag, magType, nst, gap, dmin, rms, net, id, updated, place, type, horizontalError, depthError, magError, magNst, status, locationSource, magSource, list);

        }

        // Close the file
        fclose(fp);
    }
 //print_list(list);
 free_list(list);
 t = time(NULL);
 end = clock();
 cpu_time = ((double) (end-start))/CLOCKS_PER_SEC;
 printf("Time Taken: %lf PID : %d PPID : %d Driver time End: %s\n", cpu_time, getpid(), getppid(), ctime(&t));
 return 0;
}

struct lnode *insert(char *data, double latitude, float longitude, float depth, float mag, char *magType, char *nst, int gap, float dmin, float rms, char *net, char *id, char *updated, char *place, char *type, float horizontalError, float depthError, float magError, int magNst, char *status, char *locationSource, char *magSource, struct lnode *list) {
 struct lnode *p;
 struct lnode *q;

 /* create a new node */
 p = (struct lnode *)malloc(sizeof(struct lnode));
 /* save data into new node */
 p->str = strdup(data);
 p->latitude = latitude;
 p->longitude = longitude;
 p->depth = depth;
 p->mag = mag;
 p->magType = strdup(magType);
 p->nst = strdup(nst);
 p->gap = gap;
 p->dmin = dmin;
 p->rms = rms;
 p->net = strdup(net);
 p->id = strdup(id);
 p->updated = strdup(updated);
 p->place = strdup(place);
 p->type = strdup(type);
 p->horizontalError = horizontalError;
 p->depthError = depthError;
 p->magError = magError;
 p->magNst = magNst;
 p->status = strdup(status);
 p->locationSource = strdup(locationSource);
 p->magSource= strdup(magSource);
 /* first, we handle the case where `data' should be the first element */
 if(list == NULL || list->latitude > latitude) {
  /* apperently this !IS! the first element */
  /* now data should [be|becomes] the first element */
  p->next = list;
  return p;
 } else {
  /* search the linked list for the right location */
  q = list;
  while(q->next != NULL && q->next->latitude < latitude) {
   q = q->next;
  }
  p->next = q->next;
  q->next = p;
  return list;
 }
}

void free_list(struct lnode *list) {
 struct lnode *p;

 while(list != NULL) {
  p = list->next;
  free(list);
  list = p;
 }
}

void print_list(struct lnode *list) {
 struct lnode *p;

 for(p = list; p != NULL; p = p->next){
  printf("%s", p->str);
  printf("%lf\n", p->latitude);
 }
}
