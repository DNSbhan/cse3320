#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>


int main(){
 char inbuf[5];
 int p[2], i, n1, n2, n3, n4, n5, n;
 char filename[] = "./u";
 if(pipe(p) < 0)
	exit(1); 
 write(p[1], filename, sizeof(filename));
 printf("Enter the Choice:\n0. For normal sorting.\n1. For 2 process.\n2. For 4 process.\n3. For 10 process.\n");
 scanf("%d", &n);
 //if(!vfork())
 //	execv("./u",NULL);
 //wait(NULL);
 //execv("./u",NULL);

 //if(!vfork()){
//	if(fork()==0)
 //		execv("./u",NULL);
//	execv("./u",NULL);
 //}
 //wait(NULL);
if(n==0){
//Normal sorting
 read(p[0], inbuf, 5);
 printf("\tNormal sort running\n\n");
 execv(inbuf,NULL);
}
if(n == 1){
//two process concurrently
 read(p[0], inbuf, 5);
 printf("\t2 processes running concurrently\n\n");
 n1 = fork();
 if(n1==0)
	execv(inbuf,NULL);
 //wait(NULL);
 execv(inbuf,NULL);
}
if(n==2){
//4 process concurrently
 read(p[0], inbuf, 5);
 printf("\t4 processes running concurrently\n\n");
 n1 = fork();
 n2 = fork();
 if(n1==0 && n2==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1==0 && n2>0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2>0)
	execv(inbuf,NULL);
}
if(n==3){
 //10 process concurrently
 read(p[0], inbuf, 5);
 printf("\t10 processes running concurrently\n\n");
 n1 = fork();
 n2 = fork();
 n3 = fork();
 if(n1>0 && n2>0 && n3>0)
	n4 = fork();
 if(n1>0 && n2>0 && n3>0 && n4>0)
	n5 = fork();
 
 if(n1>0 && n2>0 && n3>0 && n4>0 && n5==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2>0 && n3>0 && n4==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1==0 && n2==0 && n3==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1==0 && n2==0 && n3>0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1==0 && n2>0 && n3==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1==0 && n2>0 && n3>0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2==0 && n3==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2==0 && n3>0) 
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2>0 && n3==0)
	execv(inbuf,NULL);
 //wait(NULL);
 if(n1>0 && n2>0 && n3>0 && n4>0 && n5>0) 
	execv(inbuf,NULL);
}
 printf("\tWrong Choice!\n\n");
 return 0;
}
